module Javatraining1 {
}
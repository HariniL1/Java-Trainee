package Multi_Thread;

import java.util.Scanner;
class Table
{	
	synchronized void printTable(int n)
	{
		for(int i=0;i<=5;i++)
		{
			System.out.println(n*i);
			
			try
			{
				Thread.sleep(500);
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
		}
	}
}	
class MyThread1 extends Thread
{
	Table t;
		
	MyThread1(Table t)
		{
			this.t=t;
		}
	public void run()
		{
			t.printTable(5);
		}
}
	
class MyThread2 extends Thread
{
	Table t;
		
	MyThread2(Table t)
		{
			this.t=t;
		}
	public void run()
		{
			t.printTable(20);
		}
}
	
public class without_sync
{
	public static void main(String[] args) 
	{
		
		Table o = new Table();
		MyThread1 t1 = new MyThread1(o);
		MyThread2 t2 = new MyThread2(o);
		
		t1.start();
		t2.start();
	}
}


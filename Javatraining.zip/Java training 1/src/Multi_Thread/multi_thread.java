package Multi_Thread;
import java.util.Scanner;

class task1 extends Thread
{
	public void run()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the value for n");
		int n =s.nextInt();
		
		for(int i=0;i<n;i++)
		{
			if(i%2==0)
			{
				System.out.println("Thread 1    :" +i*i*i);
			}
		}
}	
}
class task2 extends Thread
{
	public void run()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the value for 'n'");
		int n =s.nextInt();
		
		for(int i=0;i<n;i++)
		{
			if(i%2==0)
			{
				System.out.println("Thread 2    :"+i);
			}
		}
	}
}

class task3 extends Thread
{
	public void run()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a value for N");
		int n=s.nextInt();
		
		for(float i=0;i<n;i++)
		{
			float b = i*i / 2;
			System.out.println("Thread 3     :"+b);
		}
	}
}
public class multi_thread 
{

	public static void main(String[] args) 
	{
		task1 T1 = new task1();
	    task2 T2 = new task2();
		task3 T3 = new task3();
		
		T1.start(); 
		T2.start();
		T3.start();

	}
}



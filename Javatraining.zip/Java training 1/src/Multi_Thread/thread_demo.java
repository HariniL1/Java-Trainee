package Multi_Thread;

public class thread_demo extends Thread
{
	public void run() //run() is already in Thread class, we need override this
	{
		System.out.println("Thread is running");
		
		for(int i=0;i<20;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}
	public static void main(String[] args) 
	{
		//create an obeject for the thread to run in the main method
		thread_demo t = new thread_demo();
		
		t.start(); //start() is used to call the thread. 

	}

}

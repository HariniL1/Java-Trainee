package Multi_Thread;
import java.util.Scanner;

public class runnable_ex implements Runnable
{
	public void run()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the n value");
		int n=s.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println(i*i);
		}
	}
	public static void main(String[] args) 
	{
		//create an object to the class
		runnable_ex r = new runnable_ex();
		Thread t = new Thread(r,"My new Thread");//when using interface we need to pass the class object to the
								//thread beacuse start() ismandatory to run a thread.
		t.start();
		
		System.out.println(t.getName());
	}

}

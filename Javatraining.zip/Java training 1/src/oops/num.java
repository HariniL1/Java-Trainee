package oops;


public class num extends parent
{

	void show1()
	{
		
		int add(int a,int b)
		{
		return a+b;
		}
	
	}
	
	num c = new num();
	c.show1();
	System.out.println(c.calc(10,10));

}


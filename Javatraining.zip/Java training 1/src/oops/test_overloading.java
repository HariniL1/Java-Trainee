package oops;

class test
{
	int calc(int a, int b, int c)
	{
		return a*b*c;
	}
	
	double calc(double a, double b, double c)
	{
		return a*b/c;
	}
	
	int calc(int a, int b)
	{
		return a-b;
	}
}

public class test_overloading  {

	public static void main(String[] args) {
		test t = new test();
		
		System.out.println(t.calc(3,4,5));
		System.out.println(t.calc(3.3,5.1,2.0));
		System.out.println(t.calc(30,10));
	}

}

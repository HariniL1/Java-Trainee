package oops;


class Emp123
{
	private int emp_id;
	private String name,dept;

	
public void setEmp_id(int emp_id)
{
	this.emp_id=emp_id;
}

public void setName(String name)
{
	this.name=name;
}

public void setDept(String dept)
{
	this.dept=dept;
}

public int getEmp_id()
{
	return this.emp_id;
}

public String getName()
{
	return this.name;
}

public String getDept()
{
	return this.dept;
}
}
	public class emp_bean 
		{

			public static void main(String[] args)
			{
		
				Emp123 e = new Emp123();
	
				e.setEmp_id(101);
				e.setName("Mani");
				e.setDept("Development");
		
			
				System.out.println("Employee ID: "+e.getEmp_id());
				System.out.println("Employee Name: "+e.getName());
				System.out.println("Employee Department: "+e.getDept());

			}
		}


package oops;

public class stat 
{
      static int c;
      
	public static void main(String[] args) {
		
		stat.c = 100;
		 System.out.println("Value of a is :"+c);
		

	}

}

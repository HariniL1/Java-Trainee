package oops;

class parent
{
	void show() //if method is defined final, it cannot be overridden
	{
		System.out.println("From parent class");
	}
	int cal(int a, int b)
	{
		return a+b;
	}
}
class child extends parent
{
	void show()
	{
		System.out.println("From child class");
	}
	
		int cal(int a, int b)
		{
			return a*b;
		}
	}


public class method_overriding {

	public static void main(String[] args)
	{
		//parent p = new parent();
		child c = new child();
		c.show();
		System.out.println(c.cal(10,10));
		
	//	p.show();
		//System.out.println(p.cal(10,10));
	}

}

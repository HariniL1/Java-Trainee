package oops;

import java.util.Scanner;

class Emp_data1
{
	Scanner s = new Scanner(System.in);
	String emp_name,company, address, dept ;
	int emp_id;
	
	
	Emp_data1()
	{
		System.out.println("Default constructor");
	}
	
	Emp_data1(String emp_name, String comp_name, String add, int emp_id, String comp_dept)
	{
		
		this.emp_name = emp_name;
		this.company = comp_name;
		this.address=add;
		this.emp_id=emp_id;
		this.dept =comp_dept;
				
	}
	
	Emp_data1(String emp_name, String add)
	{
		this.emp_name=emp_name;
		this.address=add;
	}


	void getData()
	{
		System.out.println("Enter the name of the Employee");
		emp_name =s.next();
		System.out.println("Enter the employee ID:");
		emp_id = s.nextInt();
		System.out.println("Enter the Company name of the Employee");
		company = s.next();
		System.out.println("Enter the Department name of the Employee");
		dept = s.next();
		System.out.println("Enter the address");
		address=s.next();
	}
	
	void display()
	{
		System.out.println("Employee name:"  +emp_name);
		System.out.println("Company name :"   +company);
		System.out.println("Address:"  +address);
		System.out.println("Employee ID:"  +emp_id);
		System.out.println("Department:"  +dept);
	}
}

public class emp_overloading
{
	public static void main(String[] args) 
	{
		
			Emp_data1 b = new Emp_data1();
			Emp_data1 b1 = new Emp_data1("Kishore", "ABC", "Canada", 001, "Finance");
			Emp_data1 b2 = new Emp_data1("Kishore", "Canada");
			
			b.getData();
			b.display();
			System.out.println("==========================");
			b1.display();
			System.out.println("==========================");
			b2.display();
			
}

}




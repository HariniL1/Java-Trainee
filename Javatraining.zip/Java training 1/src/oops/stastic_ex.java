package oops;
import java.util.*;

class leap_year
{
	static int year = 1981;
	
	static void year()
	{
		
			
		if(year%4==0)
		{
			System.out.println("Given year is a leap year:" +year);
		}
		else
		{
			System.out.println("Given year is not a leap year :" +year);
		}
	}
}
public class stastic_ex
{
	public static void main(String[] args)
	{
		leap_year.year();
		leap_year.year= 2024;
		leap_year.year();
	}

}

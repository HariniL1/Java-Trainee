package oops;


abstract class shape

{
	abstract String draw();
}

class circle extends shape
{
	String draw()
	{
	return "Iam a from circle class";
	}
}

class square extends shape
{
	String draw()
	{
       return "Iam a from square class";
	}
}

class rectangle extends shape
{
	String draw()
	{
	   return "Iam a from rectangle class";
	}
}
public class shape_ex {

	public static void main(String[] args) 
	{
		circle c = new circle();
		square s = new square();
		rectangle r = new rectangle();
		
		System.out.println("Circle is drawing -->   " +c.draw());
		System.out.println("Square is drawing -->  " +s.draw());
		System.out.println("Rectangle is drawing -->   " +r.draw());
	}

}

package oops;

public class final_ex 
{
	String  nric_no = "s997867i"; //once variable is final, cannot be changed 
	
	public static void main(String[] args) 
	{
	final_ex f = new final_ex();
	
	System.out.println("Before update:"+f.nric_no);
	
	f.nric_no="ty78789i";
	System.out.println("After update:" +f.nric_no);
	}

}
// to see how final variable works
//please add the keyword final in line 5 before String
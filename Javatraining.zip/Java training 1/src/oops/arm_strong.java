package oops;

import java.util.Scanner;

public class arm_strong 
{
	static void isArmstrong(int number)
	{
		int check, sum=0, rem;
		check = number;
		
		while(check!=0)
		{
			rem=check%10;
			sum=sum+(rem*rem*rem);
			check=check/10;
		}
		if(sum==number)
		{
			System.out.println(number + " : is Armstrong number");
			
		} 
		else
		{
			System.out.println(number + " : is not Armstrong number");
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Enter the number");
		Scanner s = new Scanner(System.in);
		int n=s.nextInt();
		
		
		arm_strong.isArmstrong(n);
	}
}

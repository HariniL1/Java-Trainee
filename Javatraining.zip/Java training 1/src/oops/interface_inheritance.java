package oops;


interface printer
{
	void print();
	default void msg()
	{
		System.out.println("from interface printer");
	}
}

interface scanner 
{
	void scan();
	
	static int cube(int n)
	{
		
		return n*n*n;
		
	}
}

class interface_demo implements scanner, printer//for multiple inheritance class interface_demo implements scanner,printer
{
	public void print()
	{
	System.out.println("Printing");
	}
	
	public void scan()
	{
		System.out.println("Scanning");
	}
}

public class interface_inheritance
{

	public static void main(String[] args) 
	{
		interface_demo i = new interface_demo();
		i.print();
		i.scan();
		i.msg();
		scanner.cube(0);
		System.out.println("result is "+scanner.cube(10));
	}

}

package oops;

interface Banks
{
	long Acc_nos = 12345678; //public static final
	
	int roi(); // public abstract
}

class dbs implements Banks
{
	public int roi()
	{
		return 15;
	}
}
public class interface_ex {

	public static void main(String[] args) 
	{
	dbs m = new dbs();
	System.out.println("HDFC interest is :" +m.roi());
//	Banks.Acc_nos = 1234444;
	System.out.println("Account num is :" +Banks.Acc_nos);//Acc_no is static by default
	//so it is interfacename.variable name is accessed this way. Cannot edit Acc_no variable
	//because it is final
	}

}

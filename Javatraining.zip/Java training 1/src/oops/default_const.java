package oops;

public class default_const 
{	
	int reg_no;
	String name;
	float marks;
	boolean result;
	
	void display()
	{
		System.out.println("reg no:" +reg_no);
		System.out.println("Name:  " +name);
		System.out.println("Marks:" +reg_no);
		System.out.println("Result :"   +result);
		
	}
	public static void main(String[] args) 
	{
	default_const d = new default_const();
	d.display();
	}

}

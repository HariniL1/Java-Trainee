package oops;

class demo
{
	int add(int a, int b)
	{
		return a+b;
	}
	
	int add(int a, int b, int c)
	{
		return a*b*c;
	}
	double add(double d1, double d2)
	{
		return d1+d2;
	}
}

public class method_overloading {

	public static void main(String[] args) {
		demo d = new demo();
		
		System.out.println(d.add(34,22));
		System.out.println(d.add(3,2,5));
		System.out.println(d.add(33.2, 45.5));
	}

}

package oops;


	class Stud_details
	{
		private int student_id;
		private String student_name,student_subject;

	
		public void setStudid(int student_id)
		{
			this.student_id=student_id;
		}

		public void setStudname(String sname)
		{
			this.student_name=sname;
		}

		public void setStudsubject(String sub)
		{
			this.student_subject=sub;
		}

		public int getStudid()
		{
			return this.student_id;
		}

		public String getStudName()
		{
			return this.student_name;
		}

		public String getStudsubject()
		{
			return this.student_subject;
		}
	}
	public class stud_pojo {

		public static void main(String[] args) 
		{

			Stud_details a = new Stud_details();

			a.setStudid(101);
			a.setStudname("Kumar");
			a.setStudsubject("Physics");
	
		
			System.out.println("Student ID: "+a.getStudid());
			System.out.println("Student Name: "+a.getStudName());
			System.out.println("Student favourite subject: "+a.getStudsubject());

		}

}

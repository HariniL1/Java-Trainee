package oops;

import java.util.Scanner;

class student1
	{
		int reg_no, mark1, mark2, mark3, tot,avg;
		String name;
		boolean result;
	
		Scanner s= new Scanner(System.in);
		
	void getData()
		{
			System.out.println("Enter the Register number");
			reg_no=s.nextInt();
			System.out.println("Enter the Name:");
			name=s.next();
			System.out.println("Enter the Marks1");
			mark1 =s.nextInt();
			System.out.println("Enter the Marks2");
			mark2 =s.nextInt();	
			System.out.println("Enter the Marks3");
			mark3 =s.nextInt();
        }
	
	}	

	class markslist extends student1
	{
		int tot, avg;
		String result;
		char grade;
		void m_list()
		{
		tot = mark1+mark2+mark3;
		avg = tot/3;
		
		if(avg>80)
		{
			grade= 'A';
		}
		else if (avg<80 && avg>=70)
		{
			grade='B';
		}
		else
		{
			grade='C';
		}
		
		if(mark1>=50 && mark2>=50 && mark3>=50)
		{
			result="pass";
		}
		else
		{
			result="fail";
		}
		}
	}
	
	class mark_data extends markslist
	{
		void report()
		{
			System.out.println("Reg no:" +reg_no);
			System.out.println("Name:" +name);
			System.out.println("Mark1:" +mark1);
			System.out.println("Mark2:" +mark2);
			System.out.println("Mark3:" +mark3);
			System.out.println("Total:" +tot);
			System.out.println("Average:" +avg);
			System.out.println("Result:" +result);
			System.out.println("Grade:" +grade);

		}
	}
public class single_inheritance {

	public static void main(String[] args) 
	{
		
		mark_data n = new mark_data();
		
		n.getData();
		n.m_list();
		n.report();

	}

}

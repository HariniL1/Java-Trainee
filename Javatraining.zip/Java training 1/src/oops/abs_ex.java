package oops;

abstract class bank
{
	bank()
	{
		System.out.println("Abstraction demo");
	}
	abstract int rate_oi(); //abstract method
	
	void show() //non abstract method
	{
		System.out.println("Concrete method from abstract class");
	}
}

class HDFC extends bank //inheritance of the abstract class
{
	
	int rate_oi()
	{
		return 12;
	}
}

class ICICI extends bank
{
	int rate_oi()
	{
		return 14;
	}
}

class SBI extends bank
{
	int rate_oi()
	{
		return 10;
	}
}
public class abs_ex 
{

	public static void main(String[] args)
	{
		HDFC h = new HDFC();
		ICICI i = new ICICI();
		SBI s = new SBI();
		
		System.out.println("HDFC interest is: " +h.rate_oi());
		System.out.println("ICICI interest is: " +i.rate_oi());
		System.out.println("SBI interest is: " +s.rate_oi());
	
	}

}

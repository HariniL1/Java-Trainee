package oops;

interface course
{
	
	void course_fee();
	
	default void coursemsg()
	{
		int id = 001;
		String name="Kishore";
		
		System.out.println("Id is : " +id);
		System.out.println("Name is : " +name);
		System.out.println("Course fee for the following courses");
		System.out.println("==============================");
	}
}

class b_tech implements course
{
	public void course_fee()
	{
		System.out.println("Fees for B.Tech is : $8000");
	}
}

class m_tech implements course
{
	public void course_fee()
	{
	System.out.println("Fees for M.Tech is : $10,000" );
	
	}
}

class medical implements course
{
	public void course_fee()
	{
	System.out.println("Fees for Medical is : $18,000" );
	}
}	

public class courses 
{

	public static void main(String[] args)
	{
		b_tech b = new b_tech();
		b.coursemsg();
		b.course_fee();
		
		m_tech mt = new m_tech();
		mt.course_fee();
		
		medical m = new medical();
		m.course_fee();
		
		
	}
	}



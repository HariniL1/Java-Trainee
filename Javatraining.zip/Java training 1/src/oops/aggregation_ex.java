package oops;


class Address
{
	String city, state, country;
	
	Address(String city, String state, String country)
	{
		this.city=city;
		this.state=state;
		this.country=country;
	}
}
class Emp
{
	int id;
	String name;
	Address address;
	
	Emp(int id,String name, Address address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	
	void display()
	{
		System.out.println(id+" "+name);
		System.out.println(address.city+" "+address.state+" "+address.country);
		System.out.println("=========================================");
		
	}
}

public class aggregation_ex 
{

	public static void main(String[] args) 
	{
		Address add1= new Address("Bangalore","Karanataka","India");
		Address add2 = new Address("Singapore","Singapore","Singapore");
		Address add3 = new Address("Malaysia","Malaysia","Malaysia");
	
		Emp e1= new Emp(111, "varun", add1);
		Emp e2= new Emp(112, "harini", add2);
		Emp e3= new Emp(113, "tejas", add3);
		
		e1.display();
		e2.display();
		e3.display();
	}

}

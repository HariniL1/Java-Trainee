package oops;

import java.util.Scanner;

 class data_emp 

{
	Scanner s = new Scanner(System.in);
	int emp_id, age;
	String emp_name, dept, company_name, address, city;
	float bas_sal,hra,da,tax,pr,tot_ear,tot_ded, gross;
	
	
	void getData()   //for reading the data or method definition
	{
		System.out.println("Enter the Employee Name");
		emp_name= s.next();
		
		System.out.println("Enter the Employee ID");
		emp_id= s.nextInt();
		
		System.out.println("Enter the Employee Basic salary");
		bas_sal = s.nextFloat();
	
}
}
	class calc extends data_emp
	{
		void calculate() //method declaration
		{
			if(bas_sal>1000 & bas_sal<2000)
			{
				hra = 12*10/100;
				da = bas_sal*12/100;
				tax= bas_sal*11/100;
				pr=bas_sal*8/100;
			}
			
			else if(bas_sal>2000 & bas_sal<3000)
			{
				hra = 15*10/100;
				da = bas_sal*15/100;
				tax= bas_sal*14/100;
				pr=bas_sal*10/100;
			}
			else if(bas_sal>3000)
			{
				hra = 17*10/100;
				da = bas_sal*16/100;
				tax= bas_sal*16/100;
				pr=bas_sal*12/100;
			}
			else
			{
				hra = 9*10/100;
				da = bas_sal*5/100;
				tax= bas_sal*5/100;
				pr=bas_sal*7/100;
			}
			
			tot_ear= bas_sal+hra+da;
			tot_ded=tax+pr;
			gross=tot_ear-tot_ded;
		}
		
		void report()//method declaration
		{
			System.out.println("==========================================");
			System.out.println("           Payslip for Jan 2022           ");
			System.out.println("==========================================");
			System.out.println("Employee Name :"+emp_name+  "\t"+   "Employee ID:" +emp_id);
			System.out.println("Basic salary : " +bas_sal +    "\t"+   "pr deduction : "+pr);
			System.out.println("HRA : "+hra+    "\t"+  "Tax:"+tax);
			System.out.println("DA:" +da);
			
			System.out.println("============================================");
			
			System.out.println("Total earnings:" +tot_ear  +"\t"+  "Total deduction:"+tot_ded);
			System.out.println("=============================================");
		
		}
	}	
		public class single_emp
		{	
			public static void main(String[] args) 
	
			{
				calc obj = new calc();
				
				for(int i=0;i<3;i++)
				{
				obj.getData();
				obj.calculate();
				obj.report();
				}

			}	

}

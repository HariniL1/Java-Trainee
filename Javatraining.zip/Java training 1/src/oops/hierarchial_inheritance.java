package oops;

import java.util.Scanner;

class stu
	{
		int reg_no, mark1, mark2, mark3, tot,avg;
		String name;
			
		Scanner s= new Scanner(System.in);
		
	void getData()
		{
			System.out.println("Enter the Register number");
			reg_no=s.nextInt();
			System.out.println("Enter the Name:");
			name=s.next();
			System.out.println("Enter the Marks1");
			mark1 =s.nextInt();
			System.out.println("Enter the Marks2");
			mark2 =s.nextInt();	
			System.out.println("Enter the Marks3");
			mark3 =s.nextInt();
        }
	
	void m_list()
	{
	tot = mark1+mark2+mark3;
	avg = tot/3;
	}
	}	

	class res_cls extends stu
	{
		String result;
		
		void result()
		{
			if(mark1>=50 && mark2>=50 && mark3>=50)
			{
				result="pass";
			}
			else
			{
				result="fail";
			}
			System.out.println("Result" + result);
		}
	}
		class grade_cls extends stu
		{
			char grade;
			
			void grade()
			{
				
				if(avg>=80)
				{	
					grade= 'A';
				}
				else if (avg<80 && avg>=70)
				{
					grade='B';
				}
				else
				{
					grade='C';
				}
			}
			
			void report()
			{
				System.out.println("Reg no:" +reg_no);
				System.out.println("Name:" +name);
				System.out.println("Mark1:" +mark1);
				System.out.println("Mark2:" +mark2);
				System.out.println("Mark3:" +mark3);
				System.out.println("Total:" +tot);
				System.out.println("Average:" +avg);
				
				System.out.println("Grade:" +grade);
			}
	   }
	

public class hierarchial_inheritance
{

	public static void main(String[] args)
	{
		
		res_cls r = new res_cls();
		grade_cls g = new grade_cls();
		
		
		g.getData();
		g.m_list();
		r.result();
		g.grade();
		g.report();
	}
}

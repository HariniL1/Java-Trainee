package oops;


class School_info
{
	String school_name,dept, location;
	
	School_info(String school_name, String dept, String location)
	{
		this.school_name=school_name;
		this.dept=dept;
		this.location=location;
	}
}

class Stud_info
{
	int reg_no;
	String name;
	School_info school;

		Stud_info(int reg_no, String name, School_info school)
		{
			this.reg_no=reg_no;
			this.name=name;
			this.school=school;
		}
		
		void show()
		{
			System.out.println(reg_no+" "+name);
			System.out.println(school.school_name+" "+school.dept+" "+school.location);
			System.out.println("=========================================");
			
		}
}
public class stud_aggre {

	public static void main(String[] args) 
	{
		School_info s1 = new School_info("Northview","Science","Yishun");
		School_info s2 = new School_info("CHIJ","Mathematics","central");
		School_info s3 = new School_info("St.Andrews","Engineering","Bishan");
		
		Stud_info st1 = new Stud_info(11,"Itisha",s1);
		Stud_info st2 = new Stud_info(03,"Tejas",s2);
		Stud_info st3 = new Stud_info(12,"Shivani",s3);
		
		st1.show();
		st2.show();
		st3.show();
		
	}	
}

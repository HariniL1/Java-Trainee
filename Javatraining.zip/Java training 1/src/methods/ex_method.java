package methods;
import java.util.Scanner;


public class ex_method

{
 int add(int n1, int n2)
 {
	 return n1+n2;
 }
 
 int sub(int n1, int n2)
 {
	 return n1-n2;
	 
 }
 
 int mul(int n1, int n2)
 {
	 return n1*n2;
 }
 
 float div(int n1, int n2)
 {
	 return n1/n2;
 }
 
	public static void main(String[] args) 
	{
		int a,b;
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter A value");
		a = s.nextInt();
		
		System.out.println("Enter B value");
		b = s.nextInt();
		
		ex_method m = new ex_method();
		
		System.out.println("===========================================");
		System.out.println("Sum of given numbers is:  " + m.add(a, b));
		
		System.out.println("===========================================");
		System.out.println("Difference of the given numbers is:  " +m.sub(a, b));
		System.out.println("===========================================");
		System.out.println("Product of the given numbers is:  " +m.mul(a, b));
		System.out.println("===========================================");
		System.out.println("Division of the given numbers is:  " +m.div(a, b));
	}

}

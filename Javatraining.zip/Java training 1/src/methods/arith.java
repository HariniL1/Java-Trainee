package methods;
import java.util.Scanner;

public class arith

{
	int num1,num2;
	float n1,n2, result;
	
	Scanner s = new Scanner(System.in);
	
	int add()
	{
		System.out.println("Enter the value for Num1");
		num1 =s.nextInt();
		System.out.println("Enter the value for number 2");
		num2=s.nextInt();
		return  num1+num2;
	}
	

	int sub()
	{
		System.out.println("Emeter the value for Num1");
		num1 =s.nextInt();
		System.out.println("Enter the value for number 2");
		num2=s.nextInt();
		return num1-num2;
	}
	
	float mul()
	{
		System.out.println("Enter the value for Num1");
		n1 =s.nextInt();
		System.out.println("Enter the value for number 2");
		n2=s.nextInt();
		return n1*n2;
	}
	
	float div()
	{
		System.out.println("Enter the value for Num1");
		n1 =s.nextInt();
		System.out.println("Enter the value for number 2");
		n2=s.nextInt();
		return  n1/n2;
	}
	
	int modulus()
	{
		System.out.println("Enter the value for Num1");
		num1 =s.nextInt();
		System.out.println("Enter the value for number 2");
		num2=s.nextInt();
		return num1%num2;
	}
	public static void main(String[] args) 
	{
		arith a = new arith();
		arith b = new arith();
		arith c = new arith();
		
		System.out.println("Addition is :" +a.add());
		int res = a.sub();
		System.out.println("Subrtaction is:"+res);
		
		System.out.println("Multiplication is :" +b.mul());
		System.out.println("Division is :" +a.div());
		System.out.println("Modulus is :" +c.modulus());
		
	}

}

package methods;
import java.util.Scanner;

public class student_data 
{
	    Scanner s = new Scanner(System.in);
		String stud_name, dob, dept, result, grade;
		int reg_no, mark1,mark2,mark3;
		float tot_mark;
		float average = 0;				
	
		
		void getData()
		{
			System.out.println("Enter the Student Name");
			stud_name= s.next();
			
			System.out.println("Enter the Student Register No");
			reg_no = s.nextInt();
			
			System.out.println("Enter the Date of Birth");
			dob = s.next();
			
			System.out.println("Enter the Department");
			dept = s.next();
			
			System.out.println("Enter the marks 1:");
			mark1 = s.nextInt();
			System.out.println("Enter the marks 2:");
			mark2 = s.nextInt();
			System.out.println("Enter the marks 3:");
			mark3 = s.nextInt();
		}

		void calculate()
		{
			tot_mark = mark1+mark2+mark3;
			average = tot_mark/3;
				
			if(mark1>=50 & mark2>=50 & mark3>=50)
			{
				result = "pass";
						
			}
			
			else 
			{
				result = "fail";
			}
			
				if(average>50 & average<70)
			{
		
			 grade = "C";
				
			}
		
			
			else if(average>70 & average<80)
			{
				grade = "B";
				
			}
		
			else if(average>80)
			{
				grade = "A";
			}
			
			else
			{
				grade = "F";
			}
		}
		
		void report()
		{
			System.out.println("==========================================");
			System.out.println("           Student mark list        ");
			System.out.println("==========================================");
			System.out.println("Student Name :"+stud_name+  "\t"+   "Date of Birth:" +dob);
			System.out.println("Register No : " +reg_no  );
			
			System.out.println("--------------------------------------------");
			
			System.out.println("Mark 1 : "+mark1+   "\t"+   "Department:"+dept);
			System.out.println("Mark 2:  " +mark2);
			System.out.println("Mark 3 :  "+mark3);
			
			System.out.println("---------------------------------------------");
			System.out.println("Total mark :" +tot_mark   +"\t"+    "Average mark : "+average);
			System.out.println("Result :" +result +    "\t"+        "Grade :" +grade);
		}
	
	public static void main(String[] args)
	
	{
		for(int i=0;i<3;i++)
		{
		student_data n =new student_data();
		n.getData();
		n.calculate();
		n.report();
		}
	}

}

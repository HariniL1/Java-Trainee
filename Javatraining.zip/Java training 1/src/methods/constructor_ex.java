package methods;

class Bank
{
	String ifsc, address,name ;
	int postal_code;
	
	Bank(String ifsc_code, String add, int post, String bank_name)
	{
		this.ifsc = ifsc_code;
		this.address=add;
		this.postal_code=post;
		this.name=bank_name;
	}


Bank()
{
	System.out.println("Default constructor");
}

void display()
{
	System.out.println("Bank name:"  +name);
	System.out.println("Address:"  +address);
	System.out.println("IFSC:"  +ifsc);
	System.out.println("Postal code:"  +postal_code);
}
}
public class constructor_ex 
{

	public static void main(String[] args) 
	{
		
			Bank b = new Bank();
			Bank b1 = new Bank("ICICI22345","Yishun,Singapore", 678890, "ICICI");
	
			//b.display();
			b1.display();
			
}
}

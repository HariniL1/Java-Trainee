package exception_handling;

public class exception_demo 
{

	public static void main(String[] args)
	{
	
		try //try block is used to excepti0n handling
		{
		int salary = 25000;
		
		
		System.out.println("Salary" +salary);
		
		int hra=salary*15/0; //abnormal condition - ArithmeticException
		System.out.println("HRA " +hra);
	   }
		catch(ArithmeticException e) // catches the exception and displays allowing further code to execute
		{
			System.out.println(e);  // e is a reference object created for the Arithmetic exception class
		}
		System.out.println();
		System.out.println("After the exception line");
		
	}
}

package exception_handling;
import java.io.*;
public class throws_ex1 
{

	void M() //throws IOException
	{
		System.out.println("Device operation performed");
	}
	
	void M1() throws ClassNotFoundException
	{
		System.out.println("Class not found exception");
	}
	public static void main(String[] args) throws IOException,ClassNotFoundException
	{
		throws_ex1 o = new throws_ex1();
		o.M();
		o.M1();
		
		System.out.println("Normal flow");
	}

}

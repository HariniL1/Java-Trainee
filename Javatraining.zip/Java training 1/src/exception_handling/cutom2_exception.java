package exception_handling;

import java.util.Scanner;

class UserAgeException extends Exception
{
	public UserAgeException(String str)
	{
		super(str);
	}
	
}
public class cutom2_exception 
{
	static void validateAge1(int age)throws UserAgeException	
	{
       Scanner s = new Scanner(System.in);
		
		System.out.println("Please enter your Age" );
	    age=s.nextInt();
		
		if(age>=10)
		{
			System.out.println("Welcome to the playground");
		}
		else
		{
			System.out.println("Sorry you are too young to enter the playground");
		}
	}
	
	
	public static void main(String[] args) throws UserAgeException
	{
		try
		{
			validateAge1(0);
		}
		catch(UserAgeException e)
		{
			System.out.println(e);
		}
		//System.out.println("Success in logging in");
	}

}

package exception_handling;

public class num_format_ex
	{
	public static void main(String[] args) 
		{
		try
		{
			int a =Integer.parseInt("null");
		}
		
		catch(NumberFormatException e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code");
		
		int decimalExample = Integer.parseInt("20"); 
		//by using parse.Int we are converting String into Integer
		int signedPositiveEx = Integer.parseInt("+20");		
		int signedNegativeEx = Integer.parseInt("-20");		
		
		System.out.println("Value = "+decimalExample);
		System.out.println("Value = "+signedPositiveEx);
		System.out.println("Value = "+signedNegativeEx);
		

		
		}
	
		
}
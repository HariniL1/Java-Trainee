package exception_handling;

public class throw_ex 
{
	static void checkAge(int age)
	{
		if(age<18)
		{
		throw new ArithmeticException("Access denied - you must be atleat 18 years old");
		}
		else
		{
			System.out.println("Success");
		}
	}
	public static void main(String[] args) 
	{
		checkAge(10);
	}

}

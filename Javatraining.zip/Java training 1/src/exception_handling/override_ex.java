package exception_handling;
import java.io.*;

class Parent
{
	void msg() throws Exception
	{
		System.out.println("Parent method");
	}
}


public class override_ex extends Parent
{
	void msg() throws Exception
	{
		System.out.println("child method");
	}
	public static void main(String[] args) throws Exception
	{
		Parent p = new override_ex(); //upcasting. creating obect from parent class to child class
		p.msg();
		
	}

}

package exception_handling;

public class index_outof_boundsex 
{
	public static void main(String[] args)
	{
	  try
		{
		int myarray[]= {1,2,3,4,5};
		System.out.println("Elements in the array----->" +myarray[2]);//change the value to 6 to handle the exception
		
		}
	  catch(Exception e)
	    {
		  System.out.println(e);
	    }
	      System.out.println("Rest of the code");
	}
}



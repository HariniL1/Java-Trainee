package exception_handling;


class invalidAgeException extends Exception
{
	public invalidAgeException(String str)
	{
		super(str);
		
	}
}
public class custom_exception {

	static void validate(int age) throws invalidAgeException
	{
		if(age<18)
		{
			throw new invalidAgeException("Age is not valid for voting ");
			
		}
		else
		{
			System.out.println("Welcome to vote");
		}
	}
	public static void main(String[] args) {
		
		try
		{
			validate(20);
		}
		catch(invalidAgeException e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code");
	}

}

package exception_handling;

public class block_with_finally 
{
	public static void main(String[] args)
	{
	try
	{
	int b=10, c=5;
	int d = b*c/0;
	System.out.println("The product of the numbers is ---->" +d);
	}
	/*catch(ArithmeticException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	*/
	finally
	{
		System.out.println("Finally executes with or without exceptions");
	}
	}
	}

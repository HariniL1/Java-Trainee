package exception_handling;

public class null_pointer_ex 
{
	
	public static void main(String[] args) 
	{
		try
		{
		String name = null;
		int str_len = name.length();
		System.out.println("Length of the string -------->" +str_len);
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		System.out.println("rest of the code");
	}
}
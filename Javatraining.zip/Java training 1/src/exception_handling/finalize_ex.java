package exception_handling;

public class finalize_ex 
{

	public static void main(String[] args) 
	{
		//creating object for finalize class
		
		finalize_ex o = new finalize_ex();
		
		System.out.println("Hash code is :"+o.hashCode());
		o = null;
		System.gc(); //cleans up memory and uses finalise() to get rid of the individual objects
		System.out.println("End of the garbage collection");

	}
	protected void finalize()
	{
		System.out.println("Called finalize() method");
	}

}

package exception_handling;
import java.util.Scanner;
public class throw_ex2 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the marks 1:");
		int m1 = s.nextInt();
		
		if(m1<50)
			{
			throw new ArithmeticException("Minimum marks should be 50 to get a pass");
			}
			else
			{
				System.out.println("Pass");
			}
		}
		
	}


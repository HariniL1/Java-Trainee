package exception_handling;

public class multiple_catch_test 
{
	public static void main(String[] args) 
	{
		try
		{
		//String a = null;
		//System.out.println(a.length());
		
		int b=10, c=5;
		int d = b*c/0;
		System.out.println("The product of the numbers is ---->" +d);
		
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println();
		System.out.println("Rest of the code");
		
	}

}

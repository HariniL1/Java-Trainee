package exception_handling;

public class multiple_catch 
{

	public static void main(String[] args)
	{
		try
		{
			String b = null;
			System.out.println(b.length());
			int a[] = new int[6];
			a[5]=43/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic exception"  +e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code");
	}

}

package collections_demo;
import java.util.*;


class Student
{
	int rollno, age;
	String name;
	
	Student (int rollno, String name, int age) //constructor
	{
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}
}
public class arr_list_user_obj {

	public static void main(String[] args) {
		
		Student s1 = new Student(101, "Abhi", 20);
		Student s2 = new Student(102, "Manu", 21);
		Student s3 = new Student(103, "Vijay", 20);
		
		ArrayList<Student> a1 = new ArrayList();
		a1.add(s1); a1.add(s2); a1.add(s3);
		
		Iterator i = a1.iterator();
		
		while(i.hasNext())
		{
			Student st =(Student)i.next();
			System.out.println(st.rollno+" "+st.name+" "+st.age);
		}
	}

}

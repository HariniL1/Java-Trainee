package collections_demo;

import java.util.*;

public class arr_methods {

	public static void main(String[] args) {
		ArrayList<String> a1 = new ArrayList<String>();
		System.out.println("Initial list of elements:" +a1);
		
		a1.add("Ravi");
		a1.add("Vijay");
		a1.add("Ajay");
		
		System.out.println("After invoking add()--------->" +a1);
		
		ArrayList<String> a12 = new ArrayList<String>();
		
		a12.add("Sonoo");
		a12.add("Hanumat");
		
		a1.addAll(a12);//without index, it adds after last element
		
		System.out.println("After invoking addAll()------>"+a1);
		
		ArrayList<String> a13=new ArrayList();
		a13.add("John");
		a13.add("Rahul");
		
		a1.addAll(0,a13); //  after 1st index, insert names in a13
		
		System.out.println("After invoking addAll index-->" +a1);
	}

}

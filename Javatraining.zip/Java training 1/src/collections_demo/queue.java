package collections_demo;

import java.util.*;
public class queue 
{
	public static void main(String[] args) 
	{
		PriorityQueue emp = new PriorityQueue();

		emp.add(1234);
		emp.add(87622);
		emp.add(2312);
		emp.add(5464);

		System.out.println("Head: "  +emp.element());
		
		Iterator i = emp.iterator();
		System.out.println("Queue elements are  :");
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		emp.remove();
		System.out.println("After removing");

		Iterator j = emp.iterator();
		while(j.hasNext())
		{
			System.out.println(j.next());
		}
	}
}

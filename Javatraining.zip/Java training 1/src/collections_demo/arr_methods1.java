package collections_demo;

import java.util.ArrayList;

public class arr_methods1 {

	public static void main(String[] args) 
	{
		ArrayList<String> a1 = new ArrayList<String>();
		System.out.println("Initial list of elements:" +a1);
		
		a1.add("Ravi");// adding arraylist
		a1.add("Vijay");
		a1.add("Ajay");
		a1.add("Gaurav");
		a1.add("Anuj");
		
		System.out.println("Initial list of elements:" +a1);
		
		a1.remove("Vijay");//removing element with value
		System.out.println("after remove():"+a1);
	
		a1.remove(0); //removing element with index
		System.out.println("after remove():"+a1);

		ArrayList<String> a12 = new ArrayList<String>();
		a12.add("Ravi");
		a12.add("Hanumat");//adding elements to a12
		a1.addAll(a12);// these elements to the existing list
		
		System.out.println("Update list :" +a1);
		
		a1.removeAll(a12);//removing only a12 list
		System.out.println("After removeAll();" +a1);
		
		a1.clear();//clear() removes all elements
		
		System.out.println("After clear()"  +a1);
	}

}

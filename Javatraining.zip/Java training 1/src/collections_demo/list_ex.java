package collections_demo;

import java.util.*;

public class list_ex {

	public static void main(String[] args)
	{
		ArrayList emp = new ArrayList(); // creating an obeject emp for ArrayList
		emp.add(1011);
		emp.add("Rani");
		emp.add(35000);	// different type of datas are stored in emp
		emp.add("India"); 
		emp.add("Singapore");
		
		System.out.println(emp);

		Iterator i = emp.iterator(); //i is the object of Iterator. emp data is moved to i now
		
		while(i.hasNext());
		{
			System.out.println(i.next());
		}
	}

}

package collections_demo;

import java.util.ArrayList;
import java.util.Collections;

public class arr_list {

	public static void main(String[] args) {
		ArrayList<String> product = new ArrayList(); // generic class
		
		product.add("101");
		product.add("books");
		product.add("1500");
		
		for(String i:product)
		{
			System.out.println(i);
			
			
		}
			Collections.sort(product);
			System.out.println();
			System.out.println("After sorting");
			System.out.println();
			for(String i:product)
			{
				System.out.println(i);
			}
	}

}

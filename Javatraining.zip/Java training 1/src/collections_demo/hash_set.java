package collections_demo;

import java.util.*;

public class hash_set 
{

	public static void main(String[] args) 
	{
		
		HashSet set = new HashSet();
		
		set.add("Ravi");
		//set.add("Ravi");
		set.add("Vijay");
		set.add("Ajay");
		set.add(null);

		Iterator i =set.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}

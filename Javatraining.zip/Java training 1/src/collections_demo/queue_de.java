package collections_demo;

import java.util.*;
import java.util.PriorityQueue;

public class queue_de {

	public static void main(String[] args) 
	{
		ArrayDeque emp = new ArrayDeque();

		emp.add("Kavitha");
		emp.add("Selvi");
		emp.add("Mallika");
		emp.add("Harini");

		System.out.println("Head: "  +emp.element());
		
		Iterator i = emp.iterator();
		System.out.println("Queue elements are  :");
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		emp.add("Sarah");
		emp.addFirst("Tejasvini");
		System.out.println("After updating");

		Iterator j = emp.iterator();
		while(j.hasNext())
		{
			System.out.println(j.next());
		}

	}

}

package collections_demo;

import java.util.ArrayList;
import java.util.*;

public class linked_list {

	public static void main(String[] args) 
	{
		
		LinkedList emp = new LinkedList(); // creating an obeject emp for ArrayList
		emp.add(1011);
		emp.add("Rani");
		emp.add(35000);	// different type of datas are stored in emp
		emp.add("India"); 
		emp.add("Singapore");
		
		System.out.println(emp);

		Iterator i = emp.iterator(); //i is the object of Iterator. emp data is moved to i now
		
		while(i.hasNext());
		{
			System.out.println(i.next());
		}

	}

}

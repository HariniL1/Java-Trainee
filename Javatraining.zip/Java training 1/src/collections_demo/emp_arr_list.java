package collections_demo;
import java.util.*;


class Employee
{
	int age, emp_id;
	String name, dept;
	
	Employee(int emp_id, String name, int age, String dept)
	{
		this.emp_id=emp_id;
		this.name=name;
		this.age=age;
		this.dept=dept;
	}
	
}
public class emp_arr_list 
{

	public static void main(String[] args) {
		
		Employee em1 = new Employee(001,"Raja",35,"Electrical");
		Employee em2 = new Employee(002,"Abdul",25,"IT");
		Employee em3 = new Employee(003,"Wong",42,"Mechanical");
		Employee em4 = new Employee(004,"Albert",30,"Electrical");
		Employee em5 = new Employee(005,"Ajay",40,"Civil");
		Employee em6 = new Employee(006,"Amit",35,"Finance");


		ArrayList<Employee> emp1 = new ArrayList();
		emp1.add(em1);emp1.add(em2);emp1.add(em3);
		emp1.add(em4); emp1.add(em5);emp1.add(em6);
		
		Iterator i = emp1.iterator(); // emp1,2,3 details are stored into i here
		
		while(i.hasNext())// i has group of elements
		{
			Employee Ed = (Employee)i.next();//ed object is created to store data in arraylist
			System.out.println(Ed.emp_id+" "+Ed.name+" "+Ed.age+" "+Ed.dept);
			//after printing emp1, will go to loop and print the next data in the list
		}
	}

}

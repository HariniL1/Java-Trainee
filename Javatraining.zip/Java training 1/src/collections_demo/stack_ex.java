package collections_demo;
import java.util.*;

public class stack_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack Stu = new Stack();
		Stu.push(1011);
		Stu.push("John");
		Stu.push(98);
		Stu.push("Pass");
		Stu.push("A grade");
		
		System.out.println(Stu);
		
		Stu.pop();
		
		Iterator i =Stu.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}

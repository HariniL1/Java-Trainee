package collections_demo;

public class linkedarr_list {

	public static void main(String[] args) {
   LinkedList<String> ll = new LinkedList<String>();

	}

}

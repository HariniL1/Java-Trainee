package Looping_stmts;

import java.util.Scanner;

public class odd_nos {

	public static void main(String[] args) 
	{
		int i = 0, nos;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter a number");
		nos = s.nextInt();
		
		System.out.println("n =" +  nos);
		for(i=1;i<=nos;)
		{
			
			System.out.println(i);
			i = i+2;
		}
	}

}

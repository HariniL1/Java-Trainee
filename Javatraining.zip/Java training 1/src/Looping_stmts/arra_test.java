package Looping_stmts;
import java.util.*;

public class arra_test {

	public static void main(String[] args) {
		
		int no_ofcourses;
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number of courses");
		no_ofcourses = s.nextInt();
		
		String course_name[] = new String[no_ofcourses];
		System.out.println("List the courses");
		
		
		System.out.println("Course name :");
		s.nextLine();
		
		for(int i=0;i<no_ofcourses;i++)
		{	
			course_name[i]=s.nextLine();	
		}

		//System.out.println("Course Name");
		System.out.println("==================");
		for(String i:course_name)
		{
			System.out.println("Registered course Name:  "+i);
			
		}
	}

}

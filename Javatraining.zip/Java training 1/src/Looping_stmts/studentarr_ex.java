package Looping_stmts;

import java.util.Scanner;

public class studentarr_ex {

	public static void main(String[] args) 
	
	{
		int no_of_stud;
		char choice;
		
		
		Scanner s = new Scanner(System.in);
		
		do
		{
		System.out.println("Enter the number of Students");
		no_of_stud = s.nextInt();
		
		int stud_regno[] = new int[no_of_stud];
		String stud_name[] = new String[no_of_stud];
		String dept[] = new String[no_of_stud];
		String result[] = new String[no_of_stud];
		
		System.out.println("Enter the students details:");
		System.out.println("=============================");
		
		for(int i =0; i<no_of_stud;i++)
		{
			System.out.println("Enter Student Register no:");
			stud_regno[i]= s.nextInt();
			
			System.out.println("Enter Student Name:");
			stud_name[i]= s.next();
			
			System.out.println("Enter student Department:");
			dept[i]= s.next();
			
			System.out.println("Enter student Result:");
			result[i]= s.next();
			
		}
		
		System.out.println("========================");
		System.out.println("Given student details");
		System.out.println("=========================");
		
		System.out.println("Student Register no ");
		System.out.println("--------------------");
		for(int i:stud_regno)
		{
			System.out.println("Register No: "+i);
			
		}
		System.out.println("=====================");
		
		System.out.println("Student Name ");
		System.out.println("--------------------");
		
		for(String i:stud_name)
		{
			System.out.println("Name: "+i);
			
		}
		System.out.println("=====================");
		System.out.println("Student Department" );
		System.out.println("--------------------");
		
		for(String i:dept)
		{
			System.out.println(" Department: "+i);
			
		}
		System.out.println("=====================");
		System.out.println("Student Result ");
		System.out.println("--------------------");
		
		for(String i:result)
		{
			System.out.println("Result: "+i);
			
		}
		System.out.println("=====================");
		System.out.println("=====================");
		
		System.out.println("Do you want to continue");
		choice = s.next().charAt(0);
	}
		while(choice!='Y');
		

}
}

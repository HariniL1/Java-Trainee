package Looping_stmts;

import java.util.Scanner;

public class doublearr_test
{

	public static void main(String[] args)
	{
	
	
	Scanner s = new Scanner(System.in);
	
	int r,c;
	
	System.out.println("Enter the number of rows");
	r=s.nextInt();
	
	System.out.println("Enter the number of columns");
	c=s.nextInt();
	
	int m1[][]= new int[r][c];
	int m2[][]= new int[r][c];
	int m3[][]= new int[r][c];
	
	System.out.println("Enter the data for table m1:");
	
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			m1[i][j]=s.nextInt();		
		}
	}
	
	System.out.println("Enter the data for table m2:");
	
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			m2[i][j]=s.nextInt();	
		}
	}
	
	System.out.println("Result of tables m1 and m2 ");
	
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
		   m3[i][j] = m1[i][j] + m2[i][j];
		}
	}
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.print(m3[i][j]+ "  ");
			}
		}
		System.out.println();
	}
		
	}
	

		

	



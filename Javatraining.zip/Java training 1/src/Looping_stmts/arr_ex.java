package Looping_stmts;

import java.util.Scanner;

public class arr_ex {

	public static void main(String[] args) 
	{
		int no_of_emps;
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the number of employees");
		no_of_emps=s.nextInt();
		
		int emp_id[] = new int[no_of_emps];
		String emp_name[] = new String[no_of_emps];
		String dept[] = new String[no_of_emps];
		
		System.out.println("Emter the Employee details");
		
		
		for(int i=0;i<no_of_emps;i++)
		{
			System.out.println("Employee id");
			emp_id[i]= s.nextInt();
			
			System.out.println("Employee name :");
			emp_name[i]=s.next();
			
		}
			System.out.println("Employee ID");
			for(int i:emp_id)
			{
				System.out.println("Employee Id:"+i);
				
			}
			System.out.println("==========================");
			
			System.out.println("Employee Name");
			for(String i:emp_name)
			{
				System.out.println("Employee Name:"+i);
				
			}
	}

}
